require_relative '../part1/src'

if $PROGRAM_NAME == __FILE__
  puts('Press ENTER for start...')
  gets
  create_files
  puts('Files F.txt, G.txt, H.txt has been created.')
end
