require 'minitest/autorun'

# really useful class
class MyTest < MiniTest::Test
  # I sincerely tried to come up with tests for this job, but alas
end
